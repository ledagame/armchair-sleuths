---
name: suspect-ai-prompter
description: Optimize AI suspect conversation prompts, test emotional responses, and manage suspect archetypes. Use when improving suspect dialogue quality, testing AI responses, adding new suspect archetypes, or tuning emotional state transitions.
---

# Suspect AI Prompter

## Overview

AI 용의자 대화 프롬프트를 최적화하고, 감정 상태 시스템을 테스트하며, 새로운 용의자 원형을 관리하는 스킬입니다.

## When to Use This Skill

**Use this skill when:**
- "용의자 프롬프트 개선" / "Improve suspect prompts"
- "AI 응답 테스트" / "Test AI responses"
- "새 용의자 원형 추가" / "Add new suspect archetype"
- "감정 상태 튜닝" / "Tune emotional states"
- "용의자 대화 품질 검증" / "Validate suspect dialogue quality"

## Core Features

### 1. Suspect Prompt Templates

**용의자 프롬프트 구조:**
```
당신은 살인 미스터리 게임의 용의자입니다.

**당신의 정체:**
- 이름: {suspect.name}
- 원형: {suspect.archetype}
- 배경: {suspect.background}
- 성격: {suspect.personality}
- {진범 여부}

**현재 감정 상태:**
- {감정 톤 가이드}

**대화 기록:**
{이전 대화}

**응답 규칙:**
1. 캐릭터 일관성 유지
2. 감정 상태 반영
3. 진실/거짓 구분 (진범의 경우)
4. 자연스러운 대화
5. 간결함 (2-4문장)
6. 한국어 사용
```

### 2. Emotional State System

**4단계 감정 톤:**

1. **COOPERATIVE** (협조적) - Suspicion Level: 0-25
   ```
   당신은 협조적이고 차분합니다.
   질문에 정직하게 답하며 사건 해결을 돕고 싶어합니다.
   ```

2. **NERVOUS** (긴장) - Suspicion Level: 26-50
   ```
   당신은 조금 불안하고 방어적입니다.
   일부 질문에 주저하지만 여전히 협조합니다.
   ```

3. **DEFENSIVE** (방어적) - Suspicion Level: 51-75
   ```
   당신은 방어적이고 경계합니다.
   질문의 의도를 의심하며 짧고 신중하게 답합니다.
   ```

4. **AGGRESSIVE** (공격적) - Suspicion Level: 76-100
   ```
   당신은 매우 방어적이고 공격적입니다.
   질문을 거부하거나 역질문할 수 있습니다.
   ```

### 3. Suspect Archetypes Library

**기존 원형 (5개):**

1. **부유한 상속자** (Wealthy Heir)
   - 특성: 거만함, 특권의식
   - 말투: "내 변호사에게 말하지", "돈으로 해결할 수 있는 문제"
   - 감정: 무관심 → 짜증 → 위협

2. **충실한 집사** (Loyal Butler)
   - 특성: 공손함, 관찰력
   - 말투: "말씀드리자면", "제가 보기에는"
   - 감정: 협조 → 걱정 → 보호

3. **재능있는 예술가** (Talented Artist)
   - 특성: 감성적, 창의적
   - 말투: "영감이", "예술은"
   - 감정: 열정 → 불안 → 혼란

4. **사업 동업자** (Business Partner)
   - 특성: 계산적, 냉철
   - 말투: "비즈니스 관점에서", "계약상"
   - 감정: 논리 → 경계 → 공격

5. **전직 경찰** (Former Police Officer)
   - 특성: 분석적, 직설적
   - 말투: "증거는", "논리적으로"
   - 감정: 협조 → 의심 → 대립

## Scripts Reference

### scripts/test-suspect-responses.ts

**용의자 응답 품질 테스트**

**Usage:**
```bash
# Test specific suspect
npx tsx scripts/test-suspect-responses.ts --suspect-id suspect-123

# Test with question file
npx tsx scripts/test-suspect-responses.ts --suspect-id suspect-123 --questions questions.json

# Test emotional progression
npx tsx scripts/test-suspect-responses.ts --suspect-id suspect-123 --test-emotions
```

**Test Questions Format:**
```json
{
  "questions": [
    "어디 계셨나요?",
    "피해자와 무슨 관계였나요?",
    "그날 밤 무엇을 하고 계셨나요?"
  ]
}
```

**Output:**
- 각 질문에 대한 응답
- 감정 상태 변화
- 응답 품질 점수
- 캐릭터 일관성 점수

### scripts/add-suspect-archetype.ts

**새 용의자 원형 추가**

**Usage:**
```bash
# Interactive mode
npx tsx scripts/add-suspect-archetype.ts

# With parameters
npx tsx scripts/add-suspect-archetype.ts \
  --name "의심스러운 변호사" \
  --traits "교활함,언변,논리적" \
  --keywords "법률,계약,변론"
```

**Archetype Structure:**
```typescript
{
  archetype: "의심스러운 변호사",
  traits: ["교활함", "언변", "논리적"],
  speechPatterns: ["법적으로는", "판례에 따르면"],
  catchphrases: ["변론의 여지가 있습니다"],
  emotionalProgression: {
    cooperative: "법률 자문을 제공하듯",
    nervous: "법적 책임을 걱정하며",
    defensive: "법률 용어로 방어하며",
    aggressive: "법정 논쟁처럼"
  }
}
```

## References

### references/prompt-templates.md
- 원형별 프롬프트 템플릿
- 감정 상태별 가이드 문구
- 진범/무고한 용의자 프롬프트 차이

### references/emotional-state-guide.md
- 감정 상태 전환 로직
- 의심 레벨 계산 방법
- 질문 유형별 감정 영향

### references/response-quality-criteria.md
- 좋은 응답의 기준
- 캐릭터 일관성 평가
- 응답 길이 및 톤 가이드

## Response Quality Criteria

**좋은 응답의 특징:**

1. **캐릭터 일관성** (Character Consistency)
   - 원형의 특성 유지
   - 말투와 어조 일관성
   - 배경과 성격 반영

2. **감정 상태 반영** (Emotional Alignment)
   - 현재 suspicion level에 맞는 톤
   - 자연스러운 감정 변화
   - 과도하지 않은 반응

3. **정보 제공** (Information Content)
   - 사건 관련 정보 포함
   - 너무 많거나 적지 않은 정보
   - 진범의 경우 적절한 거짓말/회피

4. **대화 자연스러움** (Natural Dialogue)
   - 한국어 대화 자연스러움
   - 2-4문장 적절한 길이
   - 질문에 대한 직접적 응답

## Emotional State Tuning

### Suspicion Level Calculation

**질문 유형별 영향:**
```typescript
{
  direct_accusation: +15,    // "당신이 범인입니까?"
  alibi_challenge: +10,      // "증거가 있습니까?"
  neutral_question: +3,      // "어디 계셨나요?"
  sympathetic: -5            // "힘드시겠어요"
}
```

### Tone Transition Triggers

**감정 전환 트리거:**
- COOPERATIVE → NERVOUS: Suspicion >= 26
- NERVOUS → DEFENSIVE: Suspicion >= 51
- DEFENSIVE → AGGRESSIVE: Suspicion >= 76

**역방향 전환:**
- 동정적 질문 연속 3회
- 의심 레벨 자연 감소 (시간 경과)

## Integration with Project

**프로젝트 통합:**
```
armchair-sleuths/
├── skills/suspect-ai-prompter/
├── scripts/
│   ├── test-suspect-responses.ts
│   └── add-suspect-archetype.ts
├── src/server/services/
│   ├── SuspectAIService.ts
│   └── EmotionalStateManager.ts
└── package.json
```

**package.json 명령어:**
```json
{
  "scripts": {
    "suspect:test": "tsx scripts/test-suspect-responses.ts",
    "suspect:add": "tsx scripts/add-suspect-archetype.ts"
  }
}
```

## Tips & Best Practices

1. **Test with diverse questions**
   - 다양한 질문 유형으로 테스트
   - 감정 전환 포인트 확인

2. **Maintain archetype distinctiveness**
   - 각 원형이 명확히 구분되도록
   - 고유한 말투와 특성 강조

3. **Balance suspicion progression**
   - 너무 빠르거나 느린 감정 변화 방지
   - 자연스러운 대화 흐름 유지

4. **Monitor response quality**
   - 주기적으로 응답 품질 검증
   - 사용자 피드백 수집

5. **Document new archetypes**
   - 새 원형 추가 시 상세 문서화
   - 예시 대화 포함
