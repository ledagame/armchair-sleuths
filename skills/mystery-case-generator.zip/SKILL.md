---
name: mystery-case-generator
description: Automate the complete murder mystery case generation pipeline from element selection to deployment. Use this skill when creating new daily cases, generating case content with images, or deploying cases to Reddit. Handles story generation, suspect creation, image generation, validation, and Reddit post creation.
---

# Mystery Case Generator

## Overview

이 스킬은 Armchair Sleuths AI 살인 미스터리 게임의 완전한 케이스 생성 파이프라인을 자동화합니다. 케이스 요소 선택부터 Reddit 배포까지 전체 워크플로우를 처리합니다.

## When to Use This Skill

**Use this skill when:**
- "새 케이스 만들어줘" / "Create a new case"
- "오늘의 케이스 생성" / "Generate today's case"
- "케이스 생성 및 배포" / "Generate and deploy case"
- "이미지 포함 케이스 생성" / "Generate case with images"
- "케이스 검증" / "Validate case"

## Core Workflow

### Complete Case Generation Pipeline

```mermaid
graph TD
    A[케이스 생성 시작] --> B[CaseElementLibrary에서 요소 선택]
    B --> C[Gemini로 스토리 생성]
    C --> D[용의자 3명 생성]
    D --> E[프로필 이미지 생성]
    E --> F[케이스 씬 이미지 생성]
    F --> G[케이스 검증]
    G --> H[KV 스토어 저장]
    H --> I[Reddit 포스트 생성]
    I --> J[배포 완료]
```

### 1. Basic Case Generation

**Command:**
```bash
npx tsx scripts/generate-case.ts
```

**What it does:**
- CaseElementLibrary에서 무기, 동기, 장소, 용의자 원형 선택
- Gemini API로 스토리 생성
- 피해자 + 용의자 3명 생성 (1명은 진범)
- 5W1H 해결책 생성

**Output:**
```typescript
{
  id: "case-2025-01-19",
  victim: { name, background, relationship },
  suspects: [
    { id, name, archetype, background, personality, isGuilty: false },
    { id, name, archetype, background, personality, isGuilty: false },
    { id, name, archetype, background, personality, isGuilty: true }
  ],
  solution: { who, what, where, when, why, how },
  weapon: { name, description },
  location: { name, description },
  generatedAt: timestamp
}
```

### 2. Case Generation with Images

**Command:**
```bash
npx tsx scripts/generate-case.ts --with-images
```

**What it does:**
- 기본 케이스 생성 (위 단계)
- 용의자 프로필 이미지 3개 생성 (Gemini Image Generation)
- 케이스 씬 이미지 1개 생성
- 이미지 URL을 케이스 데이터에 추가

**Image Generation Details:**
- **Suspect Images**: Professional portrait photographs (512x512)
- **Case Scene**: Crime scene illustration (512x512)
- **Format**: Base64 data URLs
- **Retry**: 최대 3회 재시도

### 3. Case Validation

**Command:**
```bash
npx tsx scripts/validate-case.ts --case-id case-2025-01-19
```

**Validation Checks:**
- ✅ 정확히 1명의 진범 존재
- ✅ 모든 5W1H 필드 존재
- ✅ 용의자 3명 존재
- ✅ 피해자 정보 완전성
- ✅ 무기/장소 정보 존재
- ✅ 모순 검사

**Output:**
```typescript
{
  isValid: boolean,
  errors: string[],
  warnings: string[],
  fixes: string[]  // 자동 수정 제안
}
```

### 4. Batch Case Validation

**Command:**
```bash
npx tsx scripts/validate-all-cases.ts
```

**What it does:**
- KV 스토어의 모든 케이스 스캔
- 각 케이스 검증
- 검증 결과 리포트 생성
- 문제 있는 케이스 목록 출력

### 5. Case Deployment to Reddit

**Command:**
```bash
npx tsx scripts/deploy-case.ts --case-id case-2025-01-19
```

**What it does:**
- 케이스 유효성 검증
- Reddit API 연동
- Devvit 포스트 생성
- 포스트 URL 반환

**Requirements:**
- Gemini API key configured
- Subreddit name
- Reddit credentials (Devvit)

## Scripts Reference

### scripts/generate-case.ts

**완전한 케이스 생성 스크립트**

**Usage:**
```bash
# Basic case
npx tsx scripts/generate-case.ts

# With images
npx tsx scripts/generate-case.ts --with-images

# Custom case ID
npx tsx scripts/generate-case.ts --case-id case-custom-2025-01-19

# Specific weapon/motive/location
npx tsx scripts/generate-case.ts --weapon poison --motive revenge
```

**Options:**
- `--with-images`: 이미지 생성 포함
- `--case-id <id>`: 커스텀 케이스 ID
- `--weapon <name>`: 특정 무기 선택
- `--motive <category>`: 특정 동기 선택
- `--location <name>`: 특정 장소 선택

**Dependencies:**
- `@google/generative-ai`
- `src/server/services/CaseGeneratorService.ts`
- `src/server/services/ImageGenerator.ts`
- `src/server/core/KVStoreManager.ts`

### scripts/validate-case.ts

**케이스 유효성 검증 스크립트**

**Usage:**
```bash
# Validate specific case
npx tsx scripts/validate-case.ts --case-id case-2025-01-19

# Validate and auto-fix
npx tsx scripts/validate-case.ts --case-id case-2025-01-19 --fix

# Verbose output
npx tsx scripts/validate-case.ts --case-id case-2025-01-19 --verbose
```

**Validation Logic:**
- Guilty suspect count check
- 5W1H completeness
- Data integrity
- Contradiction detection

### scripts/validate-all-cases.ts

**전체 케이스 배치 검증**

**Usage:**
```bash
# Validate all cases
npx tsx scripts/validate-all-cases.ts

# Fix all issues
npx tsx scripts/validate-all-cases.ts --fix-errors

# Export report
npx tsx scripts/validate-all-cases.ts --export report.json
```

### scripts/deploy-case.ts

**Reddit 배포 스크립트**

**Usage:**
```bash
# Deploy specific case
npx tsx scripts/deploy-case.ts --case-id case-2025-01-19

# Deploy today's case
npx tsx scripts/deploy-case.ts --today

# Test mode (no actual post)
npx tsx scripts/deploy-case.ts --case-id case-2025-01-19 --dry-run
```

## References

### references/case-generation-workflow.md
- 상세한 케이스 생성 워크플로우
- Gemini 프롬프트 템플릿
- 케이스 요소 선택 로직

### references/case-elements-library.json
- 무기 라이브러리 (6개)
- 동기 라이브러리 (5개)
- 장소 라이브러리 (5개)
- 용의자 원형 라이브러리 (5개)

### references/validation-rules.md
- 케이스 검증 규칙 상세
- 오류 수정 가이드
- 베스트 프랙티스

## Error Handling

### Common Errors

**1. "No guilty suspect found"**
```bash
# Fix: Ensure exactly one suspect has isGuilty: true
npx tsx scripts/validate-case.ts --case-id <id> --fix
```

**2. "Missing 5W1H field"**
```bash
# Check solution object completeness
# All fields required: who, what, where, when, why, how
```

**3. "Image generation failed"**
```bash
# Retry with exponential backoff
npx tsx scripts/generate-case.ts --case-id <id> --regenerate-images
```

**4. "Gemini API key not configured"**
```bash
# Set environment variable
export GEMINI_API_KEY=your_api_key_here
```

## Integration with Project

이 스킬의 스크립트는 다음 프로젝트 구조와 통합됩니다:

```
armchair-sleuths/
├── skills/mystery-case-generator/     # 이 스킬
├── scripts/                            # 프로젝트 스크립트 (스킬에서 복사)
│   ├── generate-case.ts
│   ├── validate-case.ts
│   └── ...
├── src/server/services/
│   ├── CaseGeneratorService.ts
│   ├── ImageGenerator.ts
│   └── ...
└── package.json                         # npm 명령어 추가
```

**package.json 명령어:**
```json
{
  "scripts": {
    "case:generate": "tsx scripts/generate-case.ts",
    "case:generate:images": "tsx scripts/generate-case.ts --with-images",
    "case:validate": "tsx scripts/validate-case.ts",
    "case:validate:all": "tsx scripts/validate-all-cases.ts",
    "case:deploy": "tsx scripts/deploy-case.ts"
  }
}
```

## Tips & Best Practices

1. **Always validate before deployment**
   ```bash
   npx tsx scripts/validate-case.ts --case-id <id> && npx tsx scripts/deploy-case.ts --case-id <id>
   ```

2. **Generate with images for better user experience**
   - 이미지는 사용자 몰입도를 크게 향상시킵니다

3. **Batch operations for efficiency**
   - 여러 케이스를 한 번에 검증할 때 validate-all-cases.ts 사용

4. **Use case IDs consistently**
   - Format: `case-YYYY-MM-DD` for daily cases
   - Format: `case-timestamp` for custom cases

5. **Monitor Gemini API usage**
   - 케이스 생성: ~3 API calls
   - 이미지 포함: ~7 API calls (4 images)

## Next Steps

스킬 생성 후:
1. ✅ 스크립트를 프로젝트 `scripts/`에 복사
2. ✅ `package.json`에 npm 명령어 추가
3. ✅ Gemini API key 설정 확인
4. ✅ 테스트 케이스 생성 및 검증
5. ✅ Reddit 배포 테스트
