---
name: gemini-image-generator
description: Generate consistent, high-quality images using Gemini API with optimized prompts for suspects, locations, and evidence. Use when generating case images, suspect profiles, or batch image operations. Handles prompt templates, style consistency, and automatic retry logic.
---

# Gemini Image Generator

## Overview

Gemini API를 활용하여 일관된 스타일의 고품질 이미지를 생성하는 스킬입니다. 용의자 프로필, 케이스 씬, 증거물 이미지 생성에 최적화되어 있습니다.

## When to Use This Skill

**Use this skill when:**
- "이미지 생성" / "Generate images"
- "용의자 프로필 이미지" / "Suspect profile images"
- "케이스 씬 이미지" / "Case scene image"
- "배치 이미지 생성" / "Batch generate images"
- "이미지 재생성" / "Regenerate images"

## Core Features

### 1. Image Types

**Suspect Profile Images (512x512)**
```
Professional portrait photograph of a {archetype}.
Character: {name}
Background: {background}
Personality: {personality}
Style: Professional headshot, cinematic lighting, shallow depth of field.
Focus: Face and upper shoulders, direct eye contact.
Quality: Photorealistic, high detail, professional photography.
Format: 512x512 portrait photograph.
Mood: Mystery, intrigue, subtle emotional expression.
```

**Case Scene Images (512x512)**
```
Crime scene illustration: {location.name}, {location.atmosphere}.
Scene includes {location.props}.
Evidence of {weapon.name}.
Dark, moody lighting.
Professional detective game art style.
No text, no people visible.
High quality, detailed, atmospheric.
```

**Evidence Images (512x512)**
```
Close-up photograph of {evidence.name}.
Context: Found at {location}.
Style: Forensic photography, dramatic lighting.
Focus: Sharp detail, texture visible.
Quality: Professional crime scene photography.
Format: 512x512 detailed photograph.
```

### 2. Prompt Templates Library

**Lighting Styles:**
- `cinematic lighting`: 영화적 조명
- `dramatic lighting`: 극적인 조명
- `dark, moody lighting`: 어둡고 분위기 있는 조명
- `forensic lighting`: 감식 조명

**Art Styles:**
- `professional photography`: 전문 사진
- `detective game art style`: 탐정 게임 아트 스타일
- `noir style`: 느와르 스타일
- `photorealistic`: 사실적 렌더링

**Mood Keywords:**
- `mystery, intrigue`: 미스터리, 흥미진진
- `dark, ominous`: 어둡고 불길한
- `atmospheric, moody`: 분위기 있는
- `tense, suspenseful`: 긴장감 있는

### 3. Batch Image Generation

**Usage:**
```bash
# Generate images for all suspects in a case
npx tsx scripts/batch-generate-images.ts --case-id case-2025-01-19 --type suspects

# Regenerate missing images
npx tsx scripts/batch-generate-images.ts --scan-missing --auto-fix

# Custom batch
npx tsx scripts/batch-generate-images.ts --batch-file images-to-generate.json
```

**Batch File Format:**
```json
{
  "images": [
    {
      "type": "suspect",
      "caseId": "case-2025-01-19",
      "suspectId": "suspect-1"
    },
    {
      "type": "scene",
      "caseId": "case-2025-01-19"
    }
  ]
}
```

### 4. Style Consistency

**Style Guidelines:**
- **Suspects**: Always professional headshots, consistent lighting
- **Scenes**: Always atmospheric, no people, focused on location
- **Evidence**: Always forensic style, sharp focus on object

**Color Palette:**
- Dark backgrounds for suspects
- Moody, limited color for scenes
- High contrast for evidence

## Scripts Reference

### scripts/batch-generate-images.ts

**배치 이미지 생성**

**Usage:**
```bash
# All suspects in case
npx tsx scripts/batch-generate-images.ts --case-id <id> --type suspects

# All images for case
npx tsx scripts/batch-generate-images.ts --case-id <id> --type all

# Scan and fix missing
npx tsx scripts/batch-generate-images.ts --scan-all --auto-fix
```

**Features:**
- Sequential generation (rate limit friendly)
- Automatic retry on failure (max 3 attempts)
- Progress tracking
- Error handling and reporting

### scripts/regenerate-missing-images.ts

**누락된 이미지 자동 감지 및 재생성**

**Usage:**
```bash
# Scan all cases
npx tsx scripts/regenerate-missing-images.ts --scan-all

# Specific case
npx tsx scripts/regenerate-missing-images.ts --case-id <id>

# Auto-fix
npx tsx scripts/regenerate-missing-images.ts --scan-all --fix
```

## References

### references/image-prompt-library.md
- 타입별 프롬프트 템플릿
- 스타일 가이드
- 키워드 라이브러리

### references/style-guide.md
- 이미지 스타일 일관성 규칙
- 색상 팔레트
- 조명 및 구도 가이드

## Integration with Project

**프로젝트 통합:**
```
armchair-sleuths/
├── skills/gemini-image-generator/
├── scripts/
│   ├── batch-generate-images.ts
│   └── regenerate-missing-images.ts
├── src/server/services/
│   └── ImageGenerator.ts
└── package.json
```

**package.json 명령어:**
```json
{
  "scripts": {
    "image:batch": "tsx scripts/batch-generate-images.ts",
    "image:fix": "tsx scripts/regenerate-missing-images.ts --scan-all --fix"
  }
}
```

## Tips & Best Practices

1. **Sequential over Parallel**
   - Gemini API rate limits 고려
   - 순차 생성으로 안정성 확보

2. **Retry Logic**
   - 실패 시 자동 재시도 (최대 3회)
   - exponential backoff 적용

3. **Prompt Consistency**
   - 같은 타입은 같은 프롬프트 패턴 사용
   - 스타일 키워드 일관성 유지

4. **Quality Check**
   - 생성 후 이미지 확인
   - 필요시 프롬프트 조정

5. **Batch Operations**
   - 대량 생성 시 배치 스크립트 사용
   - 진행 상황 모니터링
